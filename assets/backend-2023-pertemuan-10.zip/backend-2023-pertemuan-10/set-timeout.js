console.log("Satu");

setTimeout(function(){
    console.log("Dua");
},3000);

console.log("Tiga");
