console.log("Edo Membuka Bowser Google Chrome.");

console.log(`
Edo download file selama 1 jam.
  Downloading 1 Hour ...
  Download Complete.
`);

console.log("Edo membuka Youtube.");